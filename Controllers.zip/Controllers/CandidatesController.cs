﻿using CAT.AID.Data;
using CAT.AID.Models;
using CAT.AID.Web.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CAT.AID.Web.Controllers
{
    [Authorize(Roles = "LeadAssessor")]
    public class CandidatesController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;

        public CandidatesController(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var data = await _db.Candidates
                .OrderByDescending(c => c.Id)
                .ToListAsync();
            return View(data);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public async Task<IActionResult> Create(Candidate m)
        {
            if (!ModelState.IsValid)
                return View(m);

            _db.Candidates.Add(m);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var m = await _db.Candidates.FindAsync(id);
            return m == null ? NotFound() : View(m);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Candidate m)
        {
            if (!ModelState.IsValid)
                return View(m);

            _db.Update(m);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Archive(int id)
        {
            var m = await _db.Candidates.FindAsync(id);
            if (m == null) return NotFound();
            m.IsArchived = true;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Assign(int id)
        {
            var candidate = await _db.Candidates.FindAsync(id);
            if (candidate == null) return NotFound();

            var assessors = await _userManager.GetUsersInRoleAsync("Assessor");
            var filtered = assessors.Where(x => x.Location == candidate.Location).ToList();

            ViewBag.Assessors = filtered;
            ViewBag.Candidate = candidate;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Assign(int id, string assessorId)
        {
            var candidate = await _db.Candidates.FindAsync(id);
            if (candidate == null) return NotFound();

            var assessment = new Assessment
            {
                CandidateId = id,
                AssessorId = assessorId,
                LeadAssessorId = _userManager.GetUserId(User)!,
                Status = AssessmentStatus.Assigned
            };

            _db.Assessments.Add(assessment);
            await _db.SaveChangesAsync();

            return RedirectToAction(nameof(Index), "Assessments");
        }
    }
}
