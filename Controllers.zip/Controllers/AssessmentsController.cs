﻿using CAT.AID.Data;
using CAT.AID.Models;
using CAT.AID.Web.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CAT.AID.Web.Controllers
{
    [Authorize]
    public class AssessmentsController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _user;

        public AssessmentsController(ApplicationDbContext db, UserManager<ApplicationUser> user)
        {
            _db = db;
            _user = user;
        }

        // --------------------------------------------------------
        // 1. Assessor — My assigned tasks
        // --------------------------------------------------------
        [Authorize(Roles = "Assessor")]
        public async Task<IActionResult> MyTasks()
        {
            var uid = _user.GetUserId(User)!;
            var list = await _db.Assessments
                .Include(a => a.Candidate)
                .Where(a => a.AssessorId == uid && a.Status != AssessmentStatus.Approved)
                .OrderByDescending(a => a.Id)
                .ToListAsync();
            return View(list);
        }

        // --------------------------------------------------------
        // 2. Assessment form (Assessor)
        // --------------------------------------------------------
        [Authorize(Roles = "Assessor")]
        public async Task<IActionResult> Perform(int id)
        {
            var a = await _db.Assessments.Include(x => x.Candidate).FirstOrDefaultAsync(x => x.Id == id);
            if (a == null) return NotFound();
            if (!a.IsEditableByAssessor) return Unauthorized();
            return View(a);
        }

        [HttpPost]
        [Authorize(Roles = "Assessor")]
        public async Task<IActionResult> Perform(int id, string assessmentDataJson, string comments)
        {
            var a = await _db.Assessments.FindAsync(id);
            if (a == null) return NotFound();

            if (!a.IsEditableByAssessor) return Unauthorized();

            a.AssessmentDataJson = assessmentDataJson;
            a.AssessorComments = comments;
            a.Status = AssessmentStatus.Submitted;
            a.SubmittedAt = DateTime.UtcNow;

            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(MyTasks));
        }

        // --------------------------------------------------------
        // 3. Lead Assessor — Review queue
        // --------------------------------------------------------
        [Authorize(Roles = "LeadAssessor")]
        public async Task<IActionResult> ReviewQueue()
        {
            var uid = _user.GetUserId(User)!;
            var list = await _db.Assessments
                .Include(a => a.Candidate)
                .Where(a => a.LeadAssessorId == uid && a.Status == AssessmentStatus.Submitted)
                .ToListAsync();
            return View(list);
        }

        // --------------------------------------------------------
        // 4. Review screen (Lead Assessor)
        // --------------------------------------------------------
        [Authorize(Roles = "LeadAssessor")]
        public async Task<IActionResult> Review(int id)
        {
            var a = await _db.Assessments.Include(x => x.Candidate).FirstOrDefaultAsync(x => x.Id == id);
            return a == null ? NotFound() : View(a);
        }

        [HttpPost]
        [Authorize(Roles = "LeadAssessor")]
        public async Task<IActionResult> Review(int id, string leadComments, string action)
        {
            var a = await _db.Assessments.FindAsync(id);
            if (a == null) return NotFound();

            a.LeadComments = leadComments;
            a.ReviewedAt = DateTime.UtcNow;

            if (action == "approve")
            {
                a.Status = AssessmentStatus.Approved;
                a.ApprovedAt = DateTime.UtcNow;
            }
            else
            {
                a.Status = AssessmentStatus.SentBack;
            }

            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(ReviewQueue));
        }

        // --------------------------------------------------------
        // 5. Candidate history (both roles)
        // --------------------------------------------------------
        public async Task<IActionResult> History(int candidateId)
        {
            var list = await _db.Assessments
                .Include(a => a.Candidate)
                .Where(a => a.CandidateId == candidateId)
                .OrderByDescending(a => a.Id)
                .ToListAsync();
            return View(list);
        }
    }
}
